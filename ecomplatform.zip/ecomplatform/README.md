# Getting Started

### Requirements
Please make sure you have IntelliJ, Java 17, maven, docker dependencies installed.

### Build and run Application

1. Unzip Application into desired folder.
2. Open Application in IntelliJ.
3. Use terminal to build and run the application using the following commands: 

build project:
`mvn clean package -DskipTests`

Note: make sure docker desktop is running

Now build docker image by running following command from root folder:
`docker compose build`

To run the Java application simply type:
`docker compose up ecomplatform`

To shutdown application please run:
`docker compose down ecomplatform`

OpenAPI 3.0 spec can be found under the default url when running the application:
`localhost:8080/v3/api-docs`

#### Running Tests
The test file can be run through the IntelliJ interface.