package com.shapan.ecomplatform.product;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductControllerTest {

    @Mock
    ProductRepository mockProductRepository;

    @InjectMocks
    ProductController underTest;

    @Test
    void shouldCreateProductSuccessfully() {
        //given
        Product p = new Product(1L, "product1", "desc", 20);
        when(mockProductRepository.save(any())).thenReturn(p);

        //when
        Product response = underTest.createProduct(p);

        //then
        assertAll(
                () -> assertNotNull(response),
                () -> assertEquals(p, response),
                () -> assertEquals(p.getId(), response.getId())
        );
    }

    @Test
    void shouldGetProductByIdSuccessfully() {
        //given
        Product p = new Product(1L, "product1", "desc", 20);
        when(mockProductRepository.findById(any())).thenReturn(java.util.Optional.of(p));

        //when
        Product response = underTest.getProductById(1L);

        //then
        assertAll(
                () -> assertNotNull(response),
                () -> assertEquals(p, response),
                () -> assertEquals(p.getId(), response.getId())
        );
    }

    @Test
    void shouldDeleteProductByIdSuccessfully() {
        //given
        Product p = new Product(1L, "product1", "desc", 20);

        when(mockProductRepository.findById(any())).thenReturn(java.util.Optional.of(p));
        doNothing().when(mockProductRepository).deleteById(any());

        String response = underTest.deleteProduct(1L);

        //then
        assertAll(
                () -> assertNotNull(response),
                () -> assertEquals("Product deleted successfully", response)
        );
    }

}