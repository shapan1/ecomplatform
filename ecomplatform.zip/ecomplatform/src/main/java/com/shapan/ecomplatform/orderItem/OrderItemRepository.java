package com.shapan.ecomplatform.orderItem;

import org.springframework.data.repository.ListCrudRepository;

public interface OrderItemRepository extends ListCrudRepository<OrderItem, Long> {
}
