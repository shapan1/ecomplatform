package com.shapan.ecomplatform.order;

import org.springframework.data.repository.ListCrudRepository;

public interface OrderRepository extends ListCrudRepository<ProductOrder, Long> {
}
