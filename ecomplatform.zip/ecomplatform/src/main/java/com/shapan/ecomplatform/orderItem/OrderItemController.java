package com.shapan.ecomplatform.orderItem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/order-items")
public class OrderItemController {

    @Autowired
    private OrderItemRepository orderItemRepository;

    @GetMapping
    public List<OrderItem> getAllOrderItems() {
        return orderItemRepository.findAll();
    }

    @GetMapping("/{id}")
    public OrderItem getOrderItemById (@PathVariable Long id) {
        return orderItemRepository.findById(id).get();
    }

    @PostMapping
    public OrderItem createOrderItem (@RequestBody OrderItem orderItem) {
        return orderItemRepository.save(orderItem);
    }

    @PutMapping("/{id}")
    public OrderItem updateOrder (@PathVariable Long id, @RequestBody OrderItem orderItem) {
        OrderItem existingOrderItem = orderItemRepository.findById(id).get();
        existingOrderItem.setOrderId(orderItem.getOrderId());
        existingOrderItem.setDescription(orderItem.getDescription());
        existingOrderItem.setQuantity(orderItem.getQuantity());
        return orderItemRepository.save(existingOrderItem);
    }

    @DeleteMapping("/{id}")
    public String deleteOrderItem(@PathVariable Long id) {
        try {
            orderItemRepository.findById(id).get();
            orderItemRepository.deleteById(id);
            return "OrderItem deleted successfully";
        } catch (Exception e) {
            return "OrderItem not found";
        }
    }

    @ExceptionHandler(NoSuchElementException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<String> handleResourceNotFoundException(NoSuchElementException e) {
        return new ResponseEntity<>("Resource not found: " + e.getMessage(), HttpStatus.NOT_FOUND);
    }
}
