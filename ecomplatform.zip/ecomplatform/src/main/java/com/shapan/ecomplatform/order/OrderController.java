package com.shapan.ecomplatform.order;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/orders")
public class OrderController {


    @Autowired
    private OrderRepository orderRepository;

    @GetMapping
    public List<ProductOrder> getAllOrders() {
        return orderRepository.findAll();
    }

    @GetMapping("/{id}")
    public ProductOrder getOrderById (@PathVariable Long id) {
        return orderRepository.findById(id).get();
    }

    @PostMapping
    public ProductOrder createOrder (@RequestBody ProductOrder productOrder) {
        return orderRepository.save(productOrder);
    }

    @PutMapping("/{id}")
    public ProductOrder updateOrder (@PathVariable Long id, @RequestBody ProductOrder productOrder) {
        ProductOrder existingProductOrder = orderRepository.findById(id).get();
        existingProductOrder.setDetails(productOrder.getDetails());
        existingProductOrder.setProductIds(productOrder.getProductIds());
        return orderRepository.save(existingProductOrder);
    }

    @DeleteMapping("/{id}")
    public String deleteOrder(@PathVariable Long id) {
        try {
            orderRepository.findById(id).get();
            orderRepository.deleteById(id);
            return "Order deleted successfully";
        } catch (Exception e) {
            return "Order not found";
        }
    }

    @ExceptionHandler(NoSuchElementException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<String> handleResourceNotFoundException(NoSuchElementException e) {
        return new ResponseEntity<>("Resource not found: " + e.getMessage(), HttpStatus.NOT_FOUND);
    }
}
