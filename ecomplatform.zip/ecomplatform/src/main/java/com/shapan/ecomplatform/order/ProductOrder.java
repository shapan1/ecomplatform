package com.shapan.ecomplatform.order;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class ProductOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "product_Ids")
    private List<Long> productIds;
    private String details;

    public ProductOrder() {
    }

    public ProductOrder(Long id, List<Long> productIds, String details) {
        this.id = id;
        this.productIds = productIds;
        this.details = details;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<Long> getProductIds() {
        return productIds;
    }

    public void setProductIds(List<Long> productIds) {
        this.productIds = productIds;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }
}
